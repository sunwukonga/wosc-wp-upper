<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/timeline/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/timeline/timeline-holder.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/timeline/timeline-item.php';