<div class="eltdf-timeline-holder <?php echo esc_attr($holder_classes); ?>" <?php echo mrseo_elated_get_inline_attrs($data_attrs); ?>>
	<div class="eltdf-timeline">
	    <?php echo do_shortcode($content); ?>
	</div>
</div>