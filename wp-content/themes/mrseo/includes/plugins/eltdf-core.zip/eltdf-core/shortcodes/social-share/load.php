<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/social-share/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/social-share/social-share.php';