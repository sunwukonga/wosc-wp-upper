<?php echo eltdf_core_get_cpt_shortcode_module_template_part('portfolio', 'parts/image', $item_style, $params); ?>

<div class="eltdf-pli-text-holder" <?php mrseo_elated_inline_style($this_object->getItemHoverBackgroundColor('transparent'));?>>
	<div class="eltdf-pli-text-wrapper">

	</div>
</div>