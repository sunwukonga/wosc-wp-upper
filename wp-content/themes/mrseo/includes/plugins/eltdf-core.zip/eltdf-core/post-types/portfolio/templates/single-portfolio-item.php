<?php

get_header();

mrseo_elated_get_title();

eltdf_core_get_single_portfolio();

get_footer();