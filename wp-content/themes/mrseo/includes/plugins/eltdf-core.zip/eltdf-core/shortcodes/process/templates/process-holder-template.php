<div <?php mrseo_elated_class_attribute($classes)?>>
    <?php echo do_shortcode($content); ?>
</div>